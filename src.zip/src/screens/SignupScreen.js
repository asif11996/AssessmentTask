import {useState} from 'react';
import AuthContent from '../components/Auth/AuthContent';
import LoadingOverlay from '../components/ui/LoadingOverlay';
import {signUp, signIn} from '../util/auth';

// import AuthContent from '../components/Auth/AuthContent';\

function SignupScreen() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  async function signupHander({email, password}) {
    console.log('email and password is .........>', email, password);
    setIsAuthenticating(true);
    await signUp(email, password);
    setIsAuthenticating(false);
  }

  if (isAuthenticating) {
    return <LoadingOverlay message="Creating user ..... " />;
  }
  return <AuthContent onAuthenticate={signupHander} />;
}

export default SignupScreen;
