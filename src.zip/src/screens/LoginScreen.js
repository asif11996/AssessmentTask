import {useState} from 'react';
import AuthContent from '../components/Auth/AuthContent';

import LoadingOverlay from '../components/ui/LoadingOverlay';
import {signUp, signIn} from '../util/auth';

function LoginScreen() {
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  async function signinHander({email, password}) {
    console.log('email and password is .........>', email, password);
    setIsAuthenticating(true);
    await signIn(email, password);
    setIsAuthenticating(false);
  }

  if (isAuthenticating) {
    return <LoadingOverlay message="Creating user ..... " />;
  }
  return <AuthContent isLogin onAuthenticate={signinHander} />;
}

export default LoginScreen;
