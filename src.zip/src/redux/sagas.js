// sagas.js
import {call, put, takeEvery} from 'redux-saga/effects';
import {LOGIN_REQUEST, loginSuccess, loginFailure} from './actions';

// Simulate a login API request (replace with your actual login logic)
const mockLoginAPI = userData =>
  new Promise((resolve, reject) => {
    setTimeout(() => {
      if (userData.username === 'John') {
        resolve({username: 'John'});
      } else {
        reject({message: 'Invalid credentials'});
      }
    }, 1000);
  });

function* handleLogin(action) {
  try {
    const user = yield call(mockLoginAPI, action.payload);
    yield put(loginSuccess(user));
  } catch (error) {
    yield put(loginFailure(error));
  }
}

function* watchLogin() {
  yield takeEvery(LOGIN_REQUEST, handleLogin);
}

export default function* rootSaga() {
  yield watchLogin();
}
