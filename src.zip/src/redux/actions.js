// actions.js
import firebase from 'firebase';

export const LOGIN_REQUEST = 'LOGIN_REQUEST';
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const LOGOUT = 'LOGOUT';

export const loginRequest = () => ({
  type: LOGIN_REQUEST,
});

export const loginSuccess = user => ({
  type: LOGIN_SUCCESS,
  payload: user,
});

export const loginFailure = error => ({
  type: LOGIN_FAILURE,
  payload: error,
});

export const logout = () => ({
  type: LOGOUT,
});

// Asynchronous action to handle user login using Firebase Auth
export const loginUser = (email, password) => {
  return async dispatch => {
    dispatch(loginRequest());

    try {
      const response = await firebase
        .auth()
        .signInWithEmailAndPassword(email, password);
      const user = response.user;
      dispatch(loginSuccess(user));
    } catch (error) {
      dispatch(loginFailure(error.message));
    }
  };
};

// Asynchronous action to handle user logout using Firebase Auth
export const logoutUser = () => {
  return async dispatch => {
    try {
      await firebase.auth().signOut();
      dispatch(logout());
    } catch (error) {
      console.error('Error logging out: ', error);
    }
  };
};
