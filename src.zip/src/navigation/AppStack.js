import * as React from 'react';
import {Button, View} from 'react-native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import HomeScreen from './../screens/HomeScreen';
import HomeStack from './HomeStack';

// import {NavigationContainer} from '@react-navigation/native';

function Profile({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Button
        onPress={() => navigation.navigate('Notifications')}
        title="Go to notifications"
      />
    </View>
  );
}

function Setting({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Button onPress={() => navigation.goBack()} title="Go back home" />
    </View>
  );
}
function Logout({navigation}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Button onPress={() => navigation.goBack()} title="Go back home" />
    </View>
  );
}

const Drawer = createDrawerNavigator();

export default function AppStack() {
  return (
    // <NavigationContainer>
    <Drawer.Navigator
      screenOptions={{
        drawerStyle: {
          // backgroundColor: '#c6cbef', //Set Drawer background
          width: 250, //Set Drawer width
        },
        headerStyle: {
          // backgroundColor: '#fdc901',
          backgroundColor: '#f4511e', //Set Header color
        },
        headerTintColor: '#fff', //Set Header text color
        headerTitleStyle: {
          fontWeight: 'bold', //Set Header text style
        },
      }}>
      <Drawer.Screen
        name="Profile"
        options={{
          //   drawerLabel: 'First page Option',
          title: 'Profile',
        }}
        component={Profile}
      />
      <Drawer.Screen
        name="Setting"
        options={{
          //   drawerLabel: 'First page Option',
          title: 'Setting',
        }}
        component={Setting}
      />
      <Drawer.Screen
        name="Logout"
        options={
          {
            // drawerLabel: 'First page Option',
            //   title: 'Logout',
          }
        }
        component={Logout}
      />
      <Drawer.Screen name="Home" component={HomeStack} />
    </Drawer.Navigator>
    // </NavigationContainer>
  );
}
